# main.py

import tkinter as tk
from mock_data import USERS

def add_user():
    name = entry_name.get()
    age = entry_age.get()
    if name and age:
        USERS.append({"id": len(USERS) + 1, "name": name, "age": int(age)})
        update_user_list()

def update_user_list():
    listbox.delete(0, tk.END)
    for user in USERS:
        listbox.insert(tk.END, f"ID: {user['id']}, Имя: {user['name']}, Возраст: {user['age']}")

root = tk.Tk()
root.title("Список пользователей")

label = tk.Label(root, text="Добавьте нового пользователя:")
label.pack()

entry_name = tk.Entry(root)
entry_name.pack()

entry_age = tk.Entry(root)
entry_age.pack()

button = tk.Button(root, text="Добавить", command=add_user)
button.pack()

listbox = tk.Listbox(root)
listbox.pack()

root.mainloop()
