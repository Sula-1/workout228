import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QTableWidget, QTableWidgetItem, QLineEdit, QPushButton

# Mock-данные для тренировок
WORKOUTS = [
    {"id": 1, "name": "Жим лёжа", "duration": 45},
    {"id": 2, "name": "Приседания", "duration": 60},
    {"id": 3, "name": "Планка", "duration": 10},
]

class WorkoutApp(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle("Тренировочный интерфейс")
        self.setGeometry(100, 100, 600, 400)

        layout = QVBoxLayout()

        # Заголовок
        label = QLabel("Список тренировок")
        label.setStyleSheet("font-size: 16px; font-weight: bold;")
        layout.addWidget(label)

        # Таблица для отображения тренировок
        self.table = QTableWidget(len(WORKOUTS), 3)
        self.table.setHorizontalHeaderLabels(["ID", "Название", "Длительность (мин)"])
        for i, workout in enumerate(WORKOUTS):
            self.table.setItem(i, 0, QTableWidgetItem(str(workout['id'])))
            self.table.setItem(i, 1, QTableWidgetItem(workout['name']))
            self.table.setItem(i, 2, QTableWidgetItem(str(workout['duration'])))
        layout.addWidget(self.table)

        # Поле ввода для новой тренировки
        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Введите название тренировки")
        layout.addWidget(self.name_input)

        self.duration_input = QLineEdit()
        self.duration_input.setPlaceholderText("Введите длительность (мин)")
        layout.addWidget(self.duration_input)

        # Кнопка добавления
        add_button = QPushButton("Добавить тренировку")
        add_button.clicked.connect(self.add_workout)
        layout.addWidget(add_button)

        self.setLayout(layout)

    def add_workout(self):
        name = self.name_input.text()
        duration = self.duration_input.text()

        if name and duration.isdigit():
            row_count = self.table.rowCount()
            self.table.insertRow(row_count)
            self.table.setItem(row_count, 0, QTableWidgetItem(str(row_count + 1)))
            self.table.setItem(row_count, 1, QTableWidgetItem(name))
            self.table.setItem(row_count, 2, QTableWidgetItem(duration))
            self.name_input.clear()
            self.duration_input.clear()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = WorkoutApp()
    window.show()
    sys.exit(app.exec_())
