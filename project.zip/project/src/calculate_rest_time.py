import pytest
from main import calculate_rest_time, add_workout, edit_workout

def test_calculate_rest_time_normal():
    assert calculate_rest_time(30, 180, 75) == 1860

def test_calculate_rest_time_zero_duration():
    assert calculate_rest_time(0, 180, 75) == 81

def test_calculate_rest_time_invalid_values():
    with pytest.raises(TypeError):
        calculate_rest_time("30", 180, 75)

def test_add_workout_success():
    # Тут можно использовать заглушку для тестирования функции добавления
    assert add_workout("Тестовая тренировка", "Силовая", "Новичок", 30, 180, 75) == "Тренировка добавлена!"

def test_edit_workout_success():
    # Тут можно использовать заглушку для тестирования функции редактирования
    assert edit_workout(1, "Обновленная тренировка", "Кардио", "Средний", 45, 170, 70) == "Тренировка обновлена!"
