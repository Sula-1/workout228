def test_unknown_intensity():
    with pytest.raises(ValueError):
        calculate_rest_time("unknown_intensity", 10)
