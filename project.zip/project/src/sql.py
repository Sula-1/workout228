import tkinter as tk
from tkinter import messagebox
import sqlite3


# Создание/подключение к базе данных
def init_db():
    conn = sqlite3.connect("fitness_app.db")
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            weight REAL,
            age INTEGER,
            fitness_goal TEXT
        )
    """)
    conn.commit()
    conn.close()


# Сохранение данных в базу
def save_data(weight, age, goal):
    if not weight or not age or not goal:
        messagebox.showerror("Ошибка", "Заполните все поля!")
        return

    try:
        weight = float(weight)
        age = int(age)
    except ValueError:
        messagebox.showerror("Ошибка", "Вес и возраст должны быть числовыми значениями!")
        return

    conn = sqlite3.connect("fitness_app.db")
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO user_data (weight, age, fitness_goal) 
        VALUES (?, ?, ?)
    """, (weight, age, goal))
    conn.commit()
    conn.close()
    messagebox.showinfo("Успех", "Данные успешно сохранены!")


# Загрузка последних данных
def load_last_data():
    conn = sqlite3.connect("fitness_app.db")
    cursor = conn.cursor()
    cursor.execute("SELECT weight, age, fitness_goal FROM user_data ORDER BY id DESC LIMIT 1")
    data = cursor.fetchone()
    conn.close()
    return data if data else (None, None, None)


# Основной интерфейс
def main():
    # Инициализация базы данных
    init_db()

    # Создание окна
    root = tk.Tk()
    root.title("Fitness Planner")

    # Загрузка последних данных
    last_data = load_last_data()

    # Поля ввода
    tk.Label(root, text="Вес (кг):").grid(row=0, column=0, padx=5, pady=5)
    weight_entry = tk.Entry(root)
    weight_entry.grid(row=0, column=1, padx=5, pady=5)
    if last_data[0]:
        weight_entry.insert(0, str(last_data[0]))

    tk.Label(root, text="Возраст:").grid(row=1, column=0, padx=5, pady=5)
    age_entry = tk.Entry(root)
    age_entry.grid(row=1, column=1, padx=5, pady=5)
    if last_data[1]:
        age_entry.insert(0, str(last_data[1]))

    tk.Label(root, text="Цель:").grid(row=2, column=0, padx=5, pady=5)
    goal_entry = tk.Entry(root)
    goal_entry.grid(row=2, column=1, padx=5, pady=5)
    if last_data[2]:
        goal_entry.insert(0, last_data[2])

    # Кнопка сохранения
    save_button = tk.Button(root, text="Сохранить", command=lambda: save_data(
        weight_entry.get(), age_entry.get(), goal_entry.get()
    ))
    save_button.grid(row=3, column=0, columnspan=2, pady=10)

    root.mainloop()


if __name__ == "__main__":
    main()
