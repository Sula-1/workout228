import requests
import tkinter as tk
from tkinter import messagebox

API_KEY = "a2ef41348bcc43d48921991dbe1220f0"  # Ваш ключ API для NewsAPI
API_URL = "https://newsapi.org/v2/everything"  # URL для получения новостей


def get_news(query):
    try:
        response = requests.get(API_URL, params={'q': query, 'apiKey': API_KEY, 'language': 'ru'})
        data = response.json()

        if response.status_code == 200:
            articles = data.get('articles', [])
            if articles:
                # Получаем только заголовки новостей
                return '\n'.join([f"{article['title']}" for article in articles])
            else:
                return "Нет новостей по запросу."
        else:
            return f"Ошибка: {data.get('message', 'Не удалось получить данные')}"
    except requests.exceptions.RequestException as e:
        return f"Ошибка при запросе: {e}"


# Создание интерфейса для новостей
def create_news_interface():
    root = tk.Tk()
    root.title("Новости по запросу")

    # Ввод запроса
    tk.Label(root, text="Введите запрос для поиска новостей:").pack(pady=5)
    query_entry = tk.Entry(root)
    query_entry.pack(pady=5)

    # Метка для отображения новостей
    news_label = tk.Label(root, text="Новости будут здесь", font=("Arial", 12), justify="left")
    news_label.pack(pady=10)

    # Функция для обработки запроса
    def on_request():
        query = query_entry.get().strip()
        if query:
            news_info = get_news(query)
            news_label.config(text=news_info)
        else:
            messagebox.showwarning("Ошибка", "Пожалуйста, введите запрос!")

    # Кнопка для получения новостей
    request_button = tk.Button(root, text="Получить новости", command=on_request)
    request_button.pack(pady=10)

    root.mainloop()


# Запуск интерфейса для новостей
create_news_interface()
