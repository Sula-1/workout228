
import sqlite3
import tkinter as tk
from tkinter import messagebox
from tkinter import ttk

# Глобальная переменная для текущего ID тренировки
current_workout_id = None

# Подключение или создание базы данных
def connect_db():
    try:
        conn = sqlite3.connect('workout_planner.db')
        return conn
    except sqlite3.Error as e:
        update_status(f"Ошибка подключения к базе данных: {e}", "red")
        return None

# Обновление структуры таблицы
def update_table_structure():
    conn = connect_db()
    if not conn:
        return

    cursor = conn.cursor()

    # Проверяем структуру таблицы
    cursor.execute("PRAGMA table_info(workouts)")
    columns = [col[1] for col in cursor.fetchall()]

    # Добавляем недостающие столбцы
    try:
        if "workout_type" not in columns:
            cursor.execute('ALTER TABLE workouts ADD COLUMN workout_type TEXT NOT NULL DEFAULT "Силовая"')
            conn.commit()

        if "fitness_level" not in columns:
            cursor.execute('ALTER TABLE workouts ADD COLUMN fitness_level TEXT NOT NULL DEFAULT "Новичок"')
            conn.commit()
    except sqlite3.Error as e:
        update_status(f"Ошибка при изменении структуры таблицы: {e}", "red")
    finally:
        conn.close()

# Создание таблицы, если она еще не существует
def create_table():
    conn = connect_db()
    if not conn:
        return

    cursor = conn.cursor()
    try:
        cursor.execute('''CREATE TABLE IF NOT EXISTS workouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            workout_name TEXT NOT NULL,
            workout_type TEXT NOT NULL DEFAULT "Силовая",
            duration INTEGER NOT NULL,
            rest_time INTEGER NOT NULL,
            height INTEGER NOT NULL,
            weight INTEGER NOT NULL,
            fitness_level TEXT NOT NULL DEFAULT "Новичок"
        )''')
        conn.commit()
    except sqlite3.Error as e:
        update_status(f"Ошибка при создании таблицы: {e}", "red")
    finally:
        conn.close()

# Функция для добавления тренировки
def add_workout():
    workout_name = entry_workout.get().strip()
    workout_type = combo_type.get().strip() or "Силовая"
    fitness_level = combo_fitness.get().strip() or "Новичок"
    try:
        duration = int(entry_duration.get().strip())
        height = int(entry_height.get().strip())
        weight = int(entry_weight.get().strip())
        rest_time = calculate_rest_time(duration, height, weight)
    except ValueError:
        update_status("Введите корректные данные!", "red")
        return

    if workout_name and workout_type and fitness_level and duration > 0 and height > 0 and weight > 0:
        conn = connect_db()
        if not conn:
            return

        cursor = conn.cursor()
        try:
            cursor.execute('''INSERT INTO workouts (workout_name, workout_type, duration, rest_time, height, weight, fitness_level) 
                              VALUES (?, ?, ?, ?, ?, ?, ?)''',
                           (workout_name, workout_type, duration, rest_time, height, weight, fitness_level))
            conn.commit()
            update_status(f"Тренировка '{workout_name}' добавлена!", "green")
        except sqlite3.Error as e:
            update_status(f"Ошибка при добавлении тренировки: {e}", "red")
        finally:
            conn.close()

        # Очистка полей ввода
        clear_input_fields()
        show_workouts()
    else:
        update_status("Заполните все поля корректно!", "red")

# Функция для отображения всех тренировок
def show_workouts():
    conn = connect_db()
    if not conn:
        return

    cursor = conn.cursor()
    try:
        cursor.execute('SELECT * FROM workouts')
        rows = cursor.fetchall()
    except sqlite3.Error as e:
        update_status(f"Ошибка при извлечении данных: {e}", "red")
        conn.close()
        return

    conn.close()

    listbox_workouts.delete(0, tk.END)
    for row in rows:
        # Обновлённый формат строки, добавлены комментарии для роста, веса и продолжительности
        listbox_workouts.insert(
            tk.END,
            f"{row[0]}. {row[1]} ({row[2]}, {row[7]}) - {row[3]} мин (Отдых: {row[4]} сек, Рост: {row[5]} см, Вес: {row[6]} кг)"
        )

    update_status("Список тренировок обновлен", "blue")

# Функция для редактирования выбранной тренировки
def edit_workout():
    try:
        selected = listbox_workouts.get(listbox_workouts.curselection())
        workout_id = int(selected.split('.')[0])  # Извлечение ID тренировки
        workout_name = selected.split('.')[1].split('(')[0].strip()
        workout_type = selected.split('(')[1].split(',')[0].strip()
        fitness_level = selected.split(',')[1].split(')')[0].strip()

        # Заполнение полей для редактирования
        entry_workout.delete(0, tk.END)
        entry_workout.insert(0, workout_name)
        combo_type.set(workout_type)
        combo_fitness.set(fitness_level)

        global current_workout_id
        current_workout_id = workout_id
    except (IndexError, ValueError):
        update_status("Выберите тренировку для редактирования!", "red")

# Функция для сохранения изменений в тренировке
def save_edit_workout():
    workout_name = entry_workout.get().strip()
    workout_type = combo_type.get().strip() or "Силовая"
    fitness_level = combo_fitness.get().strip() or "Новичок"
    try:
        duration = int(entry_duration.get().strip())
        height = int(entry_height.get().strip())
        weight = int(entry_weight.get().strip())
        rest_time = calculate_rest_time(duration, height, weight)
    except ValueError:
        update_status("Введите корректные данные!", "red")
        return

    if workout_name and workout_type and fitness_level and duration > 0 and height > 0 and weight > 0:
        conn = connect_db()
        if not conn:
            return

        cursor = conn.cursor()
        try:
            cursor.execute('''UPDATE workouts 
                              SET workout_name = ?, workout_type = ?, duration = ?, rest_time = ?, height = ?, weight = ?, fitness_level = ? 
                              WHERE id = ?''',
                           (workout_name, workout_type, duration, rest_time, height, weight, fitness_level, current_workout_id))
            conn.commit()
            conn.close()
            update_status(f"Тренировка с ID {current_workout_id} обновлена!", "green")
            show_workouts()
        except sqlite3.Error as e:
            update_status(f"Ошибка при обновлении тренировки: {e}", "red")

        clear_input_fields()
    else:
        update_status("Заполните все поля корректно!", "red")

# Функция для удаления выбранной тренировки
def delete_workout():
    try:
        selected = listbox_workouts.get(listbox_workouts.curselection())
        workout_id = int(selected.split('.')[0])  # Извлечение ID тренировки
        result = messagebox.askyesno("Подтверждение", f"Вы уверены, что хотите удалить тренировку с ID {workout_id}?")

        if result:  # Если пользователь подтвердил удаление
            conn = connect_db()
            if not conn:
                return

            cursor = conn.cursor()
            cursor.execute('DELETE FROM workouts WHERE id = ?', (workout_id,))
            conn.commit()
            conn.close()

            update_status(f"Тренировка с ID {workout_id} удалена.", "green")
            show_workouts()
        else:
            update_status("Удаление отменено.", "blue")

    except (IndexError, ValueError):
        update_status("Выберите тренировку для удаления!", "red")

# Функция для расчёта времени отдыха
def calculate_rest_time(duration, height, weight, factor=0.1):
    return int((duration * factor * 60) + (height * 0.2) + (weight * 0.3))

# Функция для обновления строки статуса
def update_status(message, color):
    status_label.config(text=message, foreground=color)

# Функция для очистки полей ввода
def clear_input_fields():
    entry_workout.delete(0, tk.END)
    combo_type.set("Силовая")
    combo_fitness.set("Новичок")
    entry_duration.delete(0, tk.END)
    entry_height.delete(0, tk.END)
    entry_weight.delete(0, tk.END)

# Создание окна
root = tk.Tk()
root.title("Планировщик тренировок")
root.geometry("900x750")

# Заголовок
title_label = tk.Label(root, text="Планировщик тренировок", font=("Helvetica", 16))
title_label.pack(pady=10)

# Список тренировок
listbox_workouts = tk.Listbox(root, width=80, height=20)
listbox_workouts.pack(pady=10)

# Кнопки управления
frame_buttons = tk.Frame(root)
frame_buttons.pack(pady=10)

button_add = tk.Button(frame_buttons, text="Добавить тренировку", command=add_workout)
button_add.grid(row=0, column=0, padx=5, pady=5)

button_edit = tk.Button(frame_buttons, text="Редактировать тренировку", command=edit_workout)
button_edit.grid(row=0, column=1, padx=5, pady=5)

button_save = tk.Button(frame_buttons, text="Сохранить изменения", command=save_edit_workout)
button_save.grid(row=0, column=2, padx=5, pady=5)

button_delete = tk.Button(frame_buttons, text="Удалить тренировку", command=delete_workout)
button_delete.grid(row=0, column=3, padx=5, pady=5)

# Ввод данных
frame_input = tk.Frame(root)
frame_input.pack(pady=10)

tk.Label(frame_input, text="Название тренировки").grid(row=0, column=0, padx=5, pady=5)
entry_workout = tk.Entry(frame_input, width=20)
entry_workout.grid(row=0, column=1, padx=5, pady=5)

tk.Label(frame_input, text="Тип тренировки").grid(row=1, column=0, padx=5, pady=5)
combo_type = ttk.Combobox(frame_input, values=["Силовая", "Кардио", "Функциональная"], width=18)
combo_type.set("Силовая")
combo_type.grid(row=1, column=1, padx=5, pady=5)

tk.Label(frame_input, text="Уровень подготовки").grid(row=2, column=0, padx=5, pady=5)
combo_fitness = ttk.Combobox(frame_input, values=["Новичок", "Средний", "Продвинутый"], width=18)
combo_fitness.set("Новичок")
combo_fitness.grid(row=2, column=1, padx=5, pady=5)

tk.Label(frame_input, text="Длительность (мин)").grid(row=3, column=0, padx=5, pady=5)
entry_duration = tk.Entry(frame_input, width=20)
entry_duration.grid(row=3, column=1, padx=5, pady=5)

tk.Label(frame_input, text="Рост (см)").grid(row=4, column=0, padx=5, pady=5)
entry_height = tk.Entry(frame_input, width=20)
entry_height.grid(row=4, column=1, padx=5, pady=5)

tk.Label(frame_input, text="Вес (кг)").grid(row=5, column=0, padx=5, pady=5)
entry_weight = tk.Entry(frame_input, width=20)
entry_weight.grid(row=5, column=1, padx=5, pady=5)

# Строка статуса
status_label = tk.Label(root, text="Статус: Готов", font=("Helvetica", 10), fg="green")
status_label.pack(pady=10)

# Инициализация базы данных и интерфейса
create_table()
update_table_structure()
show_workouts()

root.mainloop()
